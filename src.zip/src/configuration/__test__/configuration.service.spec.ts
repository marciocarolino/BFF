import { Test, TestingModule } from '@nestjs/testing';
import { ConfigurationService } from '../configuration.service';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { UpdateParamsDTO } from '../dto/UpdateConfigurationDTO';
import { CreateConfigurationDTO } from '../dto/createConfiguration.dto';

describe('ConfigurationService', () => {
  let service: ConfigurationService;
  let axiosMock: MockAdapter;

  beforeAll(() => {
    process.env.API = 'http://localhost';
  });

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ConfigurationService],
    }).compile();

    service = module.get<ConfigurationService>(ConfigurationService);
    axiosMock = new MockAdapter(axios);
  });

  afterEach(() => {
    axiosMock.reset();
  });

  afterAll(() => {
    jest.resetAllMocks(); // Restaurar mocks após todos os testes
  });

  describe('getAll', () => {
    it('should return configurations', async () => {
      const mockResponse = {
        data: {
          docs: null, // ou qualquer outro valor que resulte em null
        },
      };
      axiosMock
        .onGet(`${process.env.API}/configuration`)
        .reply(200, mockResponse);

      const result = await service.getAll();

      expect(result || []).toEqual([]); // Se result for null, considera como array vazio
    });

    it('should handle error and return an empty array', async () => {
      // Configuração do Mock para simular um erro
      axiosMock.onGet(`${process.env.API}/configuration`).reply(500);

      // Execução do método
      const result = await service.getAll();

      // Expectativa
      expect(result).toEqual([]);
    });

    it('should handle null response and return an empty array', async () => {
      // Configuração do Mock para simular uma resposta com dados nulos
      const mockResponse = { data: { docs: null } };
      axiosMock
        .onGet(`${process.env.API}/configuration`)
        .reply(200, mockResponse);

      // Execução do método
      const result = await service.getAll();

      // Expectativa
      expect(result || []).toEqual([]);
    });
  });
});
